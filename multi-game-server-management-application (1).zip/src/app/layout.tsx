import type { Metadata } from "next";
import { Inter, JetBrains_Mono, Quicksand } from "next/font/google";
import type { ReactNode } from "react";
import { Shell } from "@/components/shell";
import "./globals.css";

const inter = Inter({ subsets: ["latin"], variable: "--font-inter" });
const quicksand = Quicksand({ subsets: ["latin"], variable: "--font-quicksand" });
const jbm = JetBrains_Mono({ subsets: ["latin"], variable: "--font-jbm" });

export const metadata: Metadata = {
  title: "Server Hub — Game Server Command Center",
  icons: { icon: "/app-icon.png", apple: "/app-icon.png" },
  description:
    "Spin up, manage and monitor game servers — Minecraft (vanilla & modded), Valheim, ARK, RuneScape: Dragonwilds, Hytale, Terraria, Rust and more.",
};

export default function RootLayout({ children }: { children: ReactNode }) {
  return (
    <html lang="en">
      <body className={`${inter.variable} ${quicksand.variable} ${jbm.variable} font-sans`}>
        <Shell>{children}</Shell>
      </body>
    </html>
  );
}
