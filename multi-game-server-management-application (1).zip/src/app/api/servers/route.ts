import { NextResponse } from "next/server";
import { asc } from "drizzle-orm";
import { db } from "@/db";
import { servers } from "@/db/schema";
import { getGame } from "@/lib/games";
import { ensureSeed } from "@/lib/seed";
import { attachIfNeeded, installFlow, metricsFor } from "@/lib/sim";

export const dynamic = "force-dynamic";

export async function GET() {
  try {
    await ensureSeed();
    const rows = await db.select().from(servers).orderBy(asc(servers.id));
    const out = [];
    for (const s of rows) {
      await attachIfNeeded(s);
      const m = s.status === "online" ? (await metricsFor(s)).at(-1) : undefined;
      out.push({
        ...s,
        game: summarize(s.gameId),
        live: m ? { cpu: m.cpu, ram: m.ram, players: m.players, tps: m.tps } : null,
      });
    }
    return NextResponse.json({ servers: out });
  } catch (e) {
    return NextResponse.json({ error: String(e) }, { status: 500 });
  }
}

function summarize(gameId: string) {
  const g = getGame(gameId);
  return { id: g.id, name: g.name, short: g.short, accent: g.accent, art: g.art, protocol: g.protocol };
}

export async function POST(req: Request) {
  try {
    const body = (await req.json()) as Partial<{
      gameId: string;
      name: string;
      version: string;
      loader: string;
      port: number;
      memoryMb: number;
      maxPlayers: number;
      motd: string;
      worldName: string;
      seed: string;
      difficulty: string;
      pvp: boolean;
    }>;
    const game = getGame(body.gameId ?? "");
    if (!game || body.gameId === undefined || !["", game.id].includes(game.id))
      return NextResponse.json({ error: "Unknown game" }, { status: 400 });
    const name = (body.name ?? "").trim();
    if (!name || name.length > 60)
      return NextResponse.json({ error: "Server name is required (max 60 chars)" }, { status: 400 });
    const port = Number(body.port ?? game.defaultPort);
    if (!Number.isInteger(port) || port < 1024 || port > 65535)
      return NextResponse.json({ error: "Port must be between 1024 and 65535" }, { status: 400 });
    const others = await db.select({ port: servers.port, name: servers.name }).from(servers);
    if (others.some((o) => o.port === port))
      return NextResponse.json({ error: `Port ${port} is already assigned to another instance` }, { status: 409 });
    const version = body.version && game.versions.includes(body.version) ? body.version : game.versions[0];
    const loader = body.loader && game.loaders?.some((l) => l.id === body.loader) ? body.loader : "vanilla";
    const memoryMb = Math.min(game.maxMemory, Math.max(game.minMemory, Number(body.memoryMb ?? game.defaultMemory)));
    const maxPlayers = Math.min(game.maxPlayersCap, Math.max(1, Number(body.maxPlayers ?? game.defaultMaxPlayers)));
    const [row] = await db
      .insert(servers)
      .values({
        name,
        gameId: game.id,
        version,
        loader,
        status: "installing",
        port,
        memoryMb,
        maxPlayers,
        motd: body.motd ?? "A Server Hub server",
        worldName: (body.worldName ?? "").trim() || "world",
        seed: body.seed ?? "",
        difficulty: body.difficulty ?? "normal",
        pvp: body.pvp ?? true,
      })
      .returning();
    void installFlow(row.id);
    return NextResponse.json({ server: row }, { status: 201 });
  } catch (e) {
    return NextResponse.json({ error: String(e) }, { status: 500 });
  }
}
