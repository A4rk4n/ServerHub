import { NextResponse } from "next/server";
import { and, eq } from "drizzle-orm";
import { db } from "@/db";
import { players, servers } from "@/db/schema";
import { act, logLine } from "@/lib/sim";

export const dynamic = "force-dynamic";

export async function POST(req: Request, ctx: { params: Promise<{ id: string; pid: string }> }) {
  const { id, pid } = await ctx.params;
  const [s] = await db.select().from(servers).where(eq(servers.id, Number(id)));
  if (!s) return NextResponse.json({ error: "Not found" }, { status: 404 });
  const [p] = await db.select().from(players).where(and(eq(players.serverId, s.id), eq(players.id, Number(pid))));
  if (!p) return NextResponse.json({ error: "Player not found" }, { status: 404 });
  const { action } = (await req.json()) as { action?: string };
  switch (action) {
    case "kick": {
      await db.update(players).set({ isOnline: false, lastSeen: new Date() }).where(eq(players.id, p.id));
      await logLine(s.id, "info", "Server", `Kicked ${p.name} from the game`);
      await act(s.id, "player", `${p.name} was kicked from ${s.name}`);
      break;
    }
    case "ban": {
      await db.update(players).set({ isBanned: true, isOnline: false, isOp: false }).where(eq(players.id, p.id));
      await logLine(s.id, "info", "Server", `Banned ${p.name}: The Ban Hammer has spoken!`);
      await act(s.id, "player", `${p.name} was banned from ${s.name}`);
      break;
    }
    case "unban": {
      await db.update(players).set({ isBanned: false }).where(eq(players.id, p.id));
      await logLine(s.id, "info", "Server", `Unbanned ${p.name}`);
      await act(s.id, "player", `${p.name} was unbanned on ${s.name}`);
      break;
    }
    case "op": {
      await db.update(players).set({ isOp: true }).where(eq(players.id, p.id));
      await logLine(s.id, "info", "Server", `Opped ${p.name}`);
      await act(s.id, "player", `${p.name} was given operator on ${s.name}`);
      break;
    }
    case "deop": {
      await db.update(players).set({ isOp: false }).where(eq(players.id, p.id));
      await logLine(s.id, "info", "Server", `De-opped ${p.name}`);
      await act(s.id, "player", `${p.name} was stripped of operator on ${s.name}`);
      break;
    }
    default:
      return NextResponse.json({ error: "Unknown action" }, { status: 400 });
  }
  const [fresh] = await db.select().from(players).where(eq(players.id, p.id));
  return NextResponse.json({ ok: true, player: fresh });
}
