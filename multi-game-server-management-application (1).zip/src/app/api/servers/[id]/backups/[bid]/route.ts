import { NextResponse } from "next/server";
import { and, eq } from "drizzle-orm";
import { db } from "@/db";
import { backups, servers } from "@/db/schema";
import { act, restoreBackup } from "@/lib/sim";

export const dynamic = "force-dynamic";

export async function DELETE(_req: Request, ctx: { params: Promise<{ id: string; bid: string }> }) {
  const { id, bid } = await ctx.params;
  const [b] = await db.select().from(backups).where(and(eq(backups.id, Number(bid)), eq(backups.serverId, Number(id))));
  if (!b) return NextResponse.json({ error: "Not found" }, { status: 404 });
  await db.delete(backups).where(eq(backups.id, b.id));
  await act(Number(id), "backup", `Backup "${b.name}" deleted`);
  return NextResponse.json({ ok: true });
}

export async function POST(req: Request, ctx: { params: Promise<{ id: string; bid: string }> }) {
  const { id, bid } = await ctx.params;
  const { action } = (await req.json()) as { action?: string };
  if (action === "restore") {
    const res = await restoreBackup(Number(id), Number(bid));
    if (!res.ok) return NextResponse.json({ error: res.reason ?? "Restore failed" }, { status: 409 });
    return NextResponse.json({ ok: true });
  }
  if (action === "manifest") {
    const [b] = await db.select().from(backups).where(eq(backups.id, Number(bid)));
    const [s] = await db.select().from(servers).where(eq(servers.id, Number(id)));
    if (!b || !s) return NextResponse.json({ error: "Not found" }, { status: 404 });
    return NextResponse.json({
      manifest: {
        backup: b.name,
        server: s.name,
        game: s.gameId,
        version: s.version,
        createdAt: b.createdAt,
        sizeMb: b.sizeMb,
        world: s.worldName,
        checksum: Array.from({ length: 4 }, () => Math.random().toString(16).slice(2, 10)).join(""),
      },
    });
  }
  return NextResponse.json({ error: "Unknown action" }, { status: 400 });
}
