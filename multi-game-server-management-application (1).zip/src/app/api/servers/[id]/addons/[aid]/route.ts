import { NextResponse } from "next/server";
import { and, eq } from "drizzle-orm";
import { db } from "@/db";
import { addons, servers } from "@/db/schema";
import { act, logLine } from "@/lib/sim";

export const dynamic = "force-dynamic";

type Ctx = { params: Promise<{ id: string; aid: string }> };

export async function PATCH(req: Request, ctx: Ctx) {
  const { id, aid } = await ctx.params;
  const [a] = await db.select().from(addons).where(and(eq(addons.id, Number(aid)), eq(addons.serverId, Number(id))));
  if (!a) return NextResponse.json({ error: "Not found" }, { status: 404 });
  const { enabled } = (await req.json()) as { enabled?: boolean };
  const [row] = await db.update(addons).set({ enabled: Boolean(enabled) }).where(eq(addons.id, a.id)).returning();
  const [s] = await db.select().from(servers).where(eq(servers.id, Number(id)));
  await logLine(Number(id), "system", "Panel", `${enabled ? "Enabled" : "Disabled"} ${a.name}${s?.status === "online" ? " — restart required" : ""}`);
  return NextResponse.json({ addon: row });
}

export async function DELETE(_req: Request, ctx: Ctx) {
  const { id, aid } = await ctx.params;
  const [a] = await db.select().from(addons).where(and(eq(addons.id, Number(aid)), eq(addons.serverId, Number(id))));
  if (!a) return NextResponse.json({ error: "Not found" }, { status: 404 });
  await db.delete(addons).where(eq(addons.id, a.id));
  await logLine(Number(id), "system", "Panel", `Uninstalled ${a.name}`);
  await act(Number(id), "addon", `${a.name} uninstalled`);
  return NextResponse.json({ ok: true });
}
