import { NextResponse } from "next/server";
import { desc, eq } from "drizzle-orm";
import { db } from "@/db";
import { addons, servers } from "@/db/schema";
import { ADDON_CATALOG } from "@/lib/catalog";
import { getGame } from "@/lib/games";
import { act, logLine } from "@/lib/sim";

export const dynamic = "force-dynamic";

export async function GET(_req: Request, ctx: { params: Promise<{ id: string }> }) {
  const { id } = await ctx.params;
  const [s] = await db.select().from(servers).where(eq(servers.id, Number(id)));
  if (!s) return NextResponse.json({ error: "Not found" }, { status: 404 });
  const g = getGame(s.gameId);
  const installed = await db.select().from(addons).where(eq(addons.serverId, s.id)).orderBy(desc(addons.id));
  const installedNames = new Set(installed.map((a) => a.name));
  const catalog = (ADDON_CATALOG[s.gameId] ?? []).map((c) => ({ ...c, installed: installedNames.has(c.name) }));
  return NextResponse.json({
    installed,
    catalog,
    source: g.modSource ?? "Workshop",
    supportsMods: g.supportsMods && catalog.length > 0,
  });
}

export async function POST(req: Request, ctx: { params: Promise<{ id: string }> }) {
  const { id } = await ctx.params;
  const [s] = await db.select().from(servers).where(eq(servers.id, Number(id)));
  if (!s) return NextResponse.json({ error: "Not found" }, { status: 404 });
  const g = getGame(s.gameId);
  if (!g.supportsMods) return NextResponse.json({ error: "This game does not support addons" }, { status: 400 });
  const { name } = (await req.json()) as { name?: string };
  const entry = (ADDON_CATALOG[s.gameId] ?? []).find((c) => c.name === name);
  if (!entry) return NextResponse.json({ error: "Not in catalog" }, { status: 404 });
  const dup = (await db.select().from(addons).where(eq(addons.serverId, s.id))).find((a) => a.name === entry.name);
  if (dup) return NextResponse.json({ error: "Already installed" }, { status: 409 });
  const [row] = await db
    .insert(addons)
    .values({
      serverId: s.id,
      name: entry.name,
      version: entry.version,
      author: entry.author,
      source: g.modSource ?? "Workshop",
      summary: entry.summary,
      downloads: entry.downloads,
    })
    .returning();
  await logLine(s.id, "success", "Panel", `Installed ${entry.name} ${entry.version} from ${g.modSource}${s.status === "online" ? " — restart required" : ""}`);
  await act(s.id, "addon", `${entry.name} ${entry.version} installed on ${s.name}`);
  return NextResponse.json({ addon: row }, { status: 201 });
}
