import { NextResponse } from "next/server";
import { and, eq } from "drizzle-orm";
import { db } from "@/db";
import { addons, files, servers } from "@/db/schema";
import { buildTree, isEditable, templateContent } from "@/lib/filesys";
import { act, logLine } from "@/lib/sim";

export const dynamic = "force-dynamic";

async function loadServer(id: string) {
  const [s] = await db.select().from(servers).where(eq(servers.id, Number(id)));
  return s ?? null;
}

export async function GET(req: Request, ctx: { params: Promise<{ id: string }> }) {
  const { id } = await ctx.params;
  const s = await loadServer(id);
  if (!s) return NextResponse.json({ error: "Not found" }, { status: 404 });
  const installed = await db.select().from(addons).where(eq(addons.serverId, s.id));
  const url = new URL(req.url);
  const path = url.searchParams.get("path");
  if (!path) {
    return NextResponse.json({ tree: buildTree(s, installed) });
  }
  const [overlay] = await db.select().from(files).where(and(eq(files.serverId, s.id), eq(files.path, path)));
  if (overlay) return NextResponse.json({ path, content: overlay.content, edited: true, editable: isEditable(path) });
  const template = templateContent(s, path);
  if (template === null) return NextResponse.json({ error: "Not a file" }, { status: 404 });
  if (!isEditable(path)) return NextResponse.json({ path, content: template, edited: false, editable: false });
  return NextResponse.json({ path, content: template, edited: false, editable: true });
}

export async function PUT(req: Request, ctx: { params: Promise<{ id: string }> }) {
  const { id } = await ctx.params;
  const s = await loadServer(id);
  if (!s) return NextResponse.json({ error: "Not found" }, { status: 404 });
  const { path, content } = (await req.json()) as { path?: string; content?: string };
  if (!path || typeof content !== "string") return NextResponse.json({ error: "path and content required" }, { status: 400 });
  if (!isEditable(path)) return NextResponse.json({ error: "This file is not editable" }, { status: 400 });
  if (content.length > 200_000) return NextResponse.json({ error: "File too large" }, { status: 400 });
  const [existing] = await db.select().from(files).where(and(eq(files.serverId, s.id), eq(files.path, path)));
  if (existing) {
    await db.update(files).set({ content, updatedAt: new Date() }).where(eq(files.id, existing.id));
  } else {
    await db.insert(files).values({ serverId: s.id, path, content });
  }
  await logLine(s.id, "system", "Panel", `Wrote ${path} (${(content.length / 1024).toFixed(1)} KB)${s.status === "online" ? " — restart required" : ""}`);
  await act(s.id, "settings", `File ${path} saved on ${s.name}`);
  return NextResponse.json({ ok: true });
}
