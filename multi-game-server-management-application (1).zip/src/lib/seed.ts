import { db } from "@/db";
import { activity, addons, backups, consoleLogs, players, servers, tasks } from "@/db/schema";
import { getGame } from "./games";
import { randInt, steam64, uuidLike } from "./format";

function ago(minutes: number): Date {
  return new Date(Date.now() - minutes * 60000);
}

function clockAt(d: Date): string {
  const p = (n: number) => String(n).padStart(2, "0");
  return `${p(d.getHours())}:${p(d.getMinutes())}:${p(d.getSeconds())}`;
}

const g = globalThis as typeof globalThis & { __hubSeed?: Promise<void> };

export function ensureSeed(): Promise<void> {
  if (!g.__hubSeed) {
    g.__hubSeed = seed().catch((e) => {
      g.__hubSeed = undefined;
      throw e;
    });
  }
  return g.__hubSeed;
}

async function seed() {
  const existing = await db.select({ id: servers.id }).from(servers).limit(1);
  if (existing.length) return;

  // ---- Server 1: Skyfall SMP (Minecraft, online) ---------------------------
  const [mc] = await db
    .insert(servers)
    .values({
      name: "Skyfall SMP",
      gameId: "minecraft",
      version: "1.21.4",
      loader: "vanilla",
      status: "online",
      port: 25565,
      memoryMb: 8192,
      maxPlayers: 40,
      motd: "Skyfall SMP — seasons, claims & community builds",
      worldName: "skyfall",
      seed: "-8675309412",
      difficulty: "normal",
      lastStartedAt: ago(135),
      createdAt: ago(60 * 24 * 21),
    })
    .returning();

  const mcBoot = ago(135);
  const mcLines: [string, string][] = [
    ["info", `[${clockAt(mcBoot)}] [main/INFO]: Booting itzg/minecraft-server:java21 with 8G heap`],
    ["info", `[${clockAt(mcBoot)}] [main/INFO]: Loading server properties`],
    ["info", `[${clockAt(new Date(mcBoot.getTime() + 2100))}] [main/INFO]: Starting Minecraft server on 0.0.0.0:25565`],
    ["info", `[${clockAt(new Date(mcBoot.getTime() + 3400))}] [Server thread/INFO]: Preparing level "skyfall"`],
    ["info", `[${clockAt(new Date(mcBoot.getTime() + 6200))}] [Worker-Main-2/INFO]: Preparing spawn area: 94%`],
    ["success", `[${clockAt(new Date(mcBoot.getTime() + 7100))}] [Server thread/INFO]: Done (5.814s)! For help, type "help"`],
    ["info", `[${clockAt(ago(18))}] [Server thread/INFO]: Saved the game`],
    ["warn", `[${clockAt(ago(9))}] [Server thread/WARN]: Can't keep up! Is the server overloaded? Running 2117ms behind`],
  ];
  await db.insert(consoleLogs).values(
    mcLines.map(([level, message], i) => ({ serverId: mc.id, level, source: "Server", message, ts: new Date(mcBoot.getTime() + i * 1400) }))
  );

  const mcPlayers = [
    ["SteveBuilt", true, true, 2914, 23],
    ["DiamondDylan", true, false, 1840, 41],
    ["RedstoneRita", true, false, 1202, 18],
    ["Ender_Eli", true, false, 980, 67],
    ["NoraTheNomad", true, false, 631, 29],
    ["CreeperHugger", false, false, 1420, 0],
    ["WitherWendy", false, false, 2402, 0],
    ["PickPete", false, false, 122, 0],
  ] as const;
  await db.insert(players).values(
    mcPlayers.map(([name, online, op, mins, ping], i) => ({
      serverId: mc.id,
      name,
      externalId: uuidLike(),
      isOnline: online,
      isOp: op,
      playMinutes: mins,
      ping,
      firstSeen: ago(60 * 24 * (19 - i)),
      lastSeen: online ? new Date() : ago(60 * randInt(3, 40)),
    }))
  );

  await db.insert(backups).values([
    { serverId: mc.id, name: "pre-update-snapshot", sizeMb: 1841, createdAt: ago(60 * 50), note: "Before 1.21.4 upgrade" },
    { serverId: mc.id, name: "auto-nightly-backup", sizeMb: 1902, createdAt: ago(60 * 26), note: "Requested by scheduler" },
    { serverId: mc.id, name: "auto-nightly-backup", sizeMb: 1918, createdAt: ago(60 * 2), note: "Requested by scheduler" },
  ]);

  await db.insert(tasks).values([
    { serverId: mc.id, name: "Nightly backup", type: "backup", intervalMin: 1440, enabled: true, lastRunAt: ago(60 * 2), nextRunAt: new Date(Date.now() + 22 * 3600e3) },
    { serverId: mc.id, name: "Restart at dawn", type: "restart", intervalMin: 1440, enabled: true, lastRunAt: ago(60 * 30), nextRunAt: new Date(Date.now() + 18 * 3600e3) },
    { serverId: mc.id, name: "Event shoutout", type: "broadcast", payload: "Build contest this Saturday — theme: FLOATING ISLANDS", intervalMin: 720, enabled: false, lastRunAt: ago(60 * 12), nextRunAt: new Date(Date.now() + 10 * 3600e3) },
  ]);

  // ---- Server 2: Emberhold (Valheim, online) --------------------------------
  const [vh] = await db
    .insert(servers)
    .values({
      name: "Emberhold",
      gameId: "valheim",
      version: "0.220.5 (Ashlands)",
      loader: "vanilla",
      status: "online",
      port: 2456,
      memoryMb: 6144,
      maxPlayers: 10,
      motd: "Emberhold — the tenth world calls",
      worldName: "Emberhold",
      seed: "Emberhold",
      createdAt: ago(60 * 24 * 12),
      lastStartedAt: ago(47),
    })
    .returning();

  const vhBoot = ago(47);
  await db.insert(consoleLogs).values([
    { serverId: vh.id, level: "info", source: "Server", message: "[Valheim] Dedicated server 0.220.5", ts: vhBoot },
    { serverId: vh.id, level: "info", source: "Server", message: '[Valheim] Loading world "Emberhold" (seed Emberhold)', ts: new Date(vhBoot.getTime() + 900) },
    { serverId: vh.id, level: "info", source: "Server", message: "[Valheim] Bound to 0.0.0.0:2456 (query 2457)", ts: new Date(vhBoot.getTime() + 2600) },
    { serverId: vh.id, level: "success", source: "Server", message: "[Valheim] Game server connected", ts: new Date(vhBoot.getTime() + 3900) },
    { serverId: vh.id, level: "info", source: "Server", message: "[Valheim] Got character ZDOID from Bjorn_Ironhide", ts: ago(32) },
    { serverId: vh.id, level: "info", source: "Server", message: "[Valheim] World saved (201.00ms)", ts: ago(8) },
  ]);

  await db.insert(players).values(
    (
      [
        ["Bjorn_Ironhide", true, true, 4120, 31],
        ["FreyaFjord", true, false, 2330, 44],
        ["RagnarTheBold", true, false, 775, 26],
        ["SigrunShield", false, false, 5021, 0],
        ["MeadMaven", false, false, 310, 0],
      ] as const
    ).map(([name, online, op, mins, ping], i) => ({
      serverId: vh.id,
      name,
      externalId: steam64(),
      isOnline: online,
      isOp: op,
      playMinutes: mins,
      ping,
      firstSeen: ago(60 * 24 * (11 - i)),
      lastSeen: online ? new Date() : ago(60 * randInt(5, 60)),
    }))
  );

  await db.insert(backups).values([
    { serverId: vh.id, name: "before-yagluth-fight", sizeMb: 1331, createdAt: ago(60 * 30), note: "Big boss night" },
  ]);
  await db.insert(tasks).values([
    { serverId: vh.id, name: "World backup", type: "backup", intervalMin: 720, enabled: true, lastRunAt: ago(240), nextRunAt: new Date(Date.now() + 8 * 3600e3) },
  ]);

  // ---- Server 3: Aberration Cluster (ARK, offline) --------------------------
  const [ark] = await db
    .insert(servers)
    .values({
      name: "Aberration Cluster",
      gameId: "ark",
      version: "357.8 (Aberration)",
      loader: "vanilla",
      status: "offline",
      port: 7777,
      memoryMb: 16384,
      maxPlayers: 32,
      motd: "PVP weekends · boosted taming x3",
      worldName: "Aberration",
      difficulty: "hard",
      createdAt: ago(60 * 24 * 40),
      lastStartedAt: ago(60 * 30),
    })
    .returning();
  await db.insert(players).values(
    (
      [
        ["DiloDave", false, true, 8110],
        ["RexyRhonda", false, false, 3345],
        ["Ascend_Amy", false, false, 1902],
      ] as const
    ).map(([name, online, op, mins]) => ({
      serverId: ark.id,
      name,
      externalId: steam64(),
      isOnline: online,
      isOp: op,
      playMinutes: mins,
      firstSeen: ago(60 * 24 * randInt(20, 39)),
      lastSeen: ago(60 * randInt(28, 90)),
    }))
  );
  await db.insert(backups).values([
    { serverId: ark.id, name: "weekly-cluster-snapshot", sizeMb: 6102, createdAt: ago(60 * 24 * 7) },
  ]);

  // ---- Server 4: Project Redux (modded MC, offline) -------------------------
  const [redux] = await db
    .insert(servers)
    .values({
      name: "Project Redux",
      gameId: "minecraft-modded",
      version: "1.21.1",
      loader: "fabric",
      status: "offline",
      port: 25566,
      memoryMb: 12288,
      maxPlayers: 25,
      motd: "Tech + magic pack · whitelist only",
      worldName: "redux",
      createdAt: ago(60 * 24 * 8),
      lastStartedAt: ago(60 * 20),
    })
    .returning();

  await db.insert(addons).values(
    (
      [
        ["Sodium", "0.6.9+mc1.21.1", "jellysquid3", 41200300],
        ["Lithium", "0.14.3", "jellysquid3", 10284700],
        ["Iris Shaders", "1.8.5", "coderbot", 22488200],
        ["Create", "6.0.1", "simibubi", 21988400],
        ["Applied Energistics 2", "19.2.1", "AlgorithmX2", 15700300],
        ["Botania", "447-SNAPSHOT", "Vazkii", 18449900],
        ["Waystones", "21.1.8", "BlayTheNinth", 9977300],
        ["JEI — Just Enough Items", "19.21.0", "mezz", 33211600],
      ] as const
    ).map(([name, version, author, downloads], i) => ({
      serverId: redux.id,
      name,
      version,
      author,
      source: "Modrinth",
      downloads,
      enabled: i !== 5,
      installedAt: ago(60 * 24 * (8 - i * 0.5)),
    }))
  );

  await db.insert(tasks).values([
    { serverId: redux.id, name: "Weekly restart", type: "restart", intervalMin: 10080, enabled: true, lastRunAt: ago(60 * 24 * 6), nextRunAt: new Date(Date.now() + 26 * 3600e3) },
  ]);

  // ---- Global activity feed --------------------------------------------------
  const acts: [number | null, string, string, number][] = [
    [mc.id, "power", "Skyfall SMP started — Minecraft listening on :25565", 135],
    [vh.id, "power", "Emberhold started — Valheim listening on :2456", 47],
    [mc.id, "player", "DiamondDylan joined Skyfall SMP", 96],
    [vh.id, "player", "FreyaFjord joined Emberhold", 33],
    [mc.id, "backup", 'Backup "auto-nightly-backup" completed (1.9 GB)', 120],
    [ark.id, "power", "Aberration Cluster stopped", 60 * 30],
    [redux.id, "addon", "Create 6.0.1 installed from Modrinth", 60 * 24 * 2],
    [ark.id, "player", "RexyRhonda left Aberration Cluster · 91m session", 60 * 31],
    [mc.id, "task", 'Scheduled restart "Restart at dawn" executed', 60 * 30],
    [vh.id, "backup", 'Backup "before-yagluth-fight" completed (1.3 GB)', 60 * 30],
    [mc.id, "server", "Skyfall SMP upgraded to Minecraft 1.21.4", 60 * 52],
    [null, "server", "Node eu-west-1 reports healthy — 41°C, load 0.62", 12],
  ];
  await db.insert(activity).values(
    acts.map(([serverId, kind, message, minutesAgo]) => ({ serverId, kind, message, ts: ago(minutesAgo) }))
  );
}
