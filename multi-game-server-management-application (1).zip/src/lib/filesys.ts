import type { Addon, Server } from "@/db/schema";
import { getGame } from "./games";

export type FsNode = {
  name: string;
  path: string;
  type: "dir" | "file";
  size?: number;
  editable?: boolean;
  children?: FsNode[];
};

const EDITABLE_EXT = ["txt", "json", "properties", "cfg", "ini", "sh", "log", "yml", "yaml", "md", "conf", "toml"];

export function isEditable(path: string): boolean {
  const ext = path.split(".").pop()?.toLowerCase() ?? "";
  return EDITABLE_EXT.includes(ext);
}

function file(path: string, sizeKb: number): FsNode {
  const name = path.split("/").pop()!;
  return { name, path, type: "file", size: sizeKb, editable: isEditable(path) };
}
function bin(path: string, sizeKb: number): FsNode {
  const name = path.split("/").pop()!;
  return { name, path, type: "file", size: sizeKb, editable: false };
}
function dir(name: string, path: string, children: FsNode[]): FsNode {
  return { name, path, type: "dir", children };
}

export function treeFor(s: Server, installed: Addon[]): { path: string; size: number }[] {
  const flat: { path: string; size: number }[] = [];
  const walk = (nodes: FsNode[]) => {
    for (const n of nodes) {
      if (n.type === "file") flat.push({ path: n.path, size: n.size ?? 1 });
      if (n.children) walk(n.children);
    }
  };
  walk(buildTree(s, installed));
  return flat;
}

export function buildTree(s: Server, installed: Addon[]): FsNode[] {
  const g = getGame(s.gameId);
  const w = s.worldName;
  switch (s.gameId) {
    case "minecraft":
    case "minecraft-modded": {
      const modded = s.gameId === "minecraft-modded";
      return [
        file("server.properties", 2),
        file("eula.txt", 1),
        file("ops.json", 1),
        file("banned-players.json", 1),
        bin("server-icon.png", 41),
        bin(modded ? `${s.loader}-${s.version}-server.jar` : "server.jar", modded ? 91200 : 66140),
        dir(modded ? "mods" : "plugins", modded ? "mods" : "plugins", [
          ...(installed.length
            ? installed.map((a) => bin(`${modded ? "mods" : "plugins"}/${a.name.replace(/\s+/g, "-")}-${a.version}.jar`, 900 + a.name.length * 37))
            : [file(modded ? "mods/README.txt" : "plugins/README.txt", 1)]),
        ]),
        dir("logs", "logs", [file("logs/latest.log", 84), bin("logs/2026-01-30-1.log.gz", 312)]),
        dir("world", "world", [
          bin("world/level.dat", 12),
          dir("region", "world/region", [bin("world/region/r.0.0.mca", 12210), bin("world/region/r.0.-1.mca", 8920), bin("world/region/r.-1.0.mca", 7640)]),
          dir("playerdata", "world/playerdata", [bin("world/playerdata/7b2c…4d.dat", 3)]),
          dir("datapacks", "world/datapacks", [dir("vanilla", "world/datapacks/vanilla", [file("world/datapacks/vanilla/pack.mcmeta", 1)])]),
        ]),
      ];
    }
    case "minecraft-bedrock":
      return [
        file("server.properties", 2),
        file("permissions.json", 1),
        bin("bedrock_server", 51200),
        dir("worlds", "worlds", [dir(w, `worlds/${w}`, [bin(`worlds/${w}/level.dat`, 8), bin(`worlds/${w}/db/000142.ldb`, 22140)])]),
        dir("logs", "logs", [file("logs/latest.log", 40)]),
      ];
    case "valheim":
      return [
        file("start_server.sh", 1),
        file("start_headless_server.sh", 1),
        dir("worlds_local", "worlds_local", [bin(`worlds_local/${w}.fwl`, 4), bin(`worlds_local/${w}.db`, 840211)]),
        dir("BepInEx", "BepInEx", [dir("config", "BepInEx/config", [file("BepInEx/config/valheim_plus.cfg", 6), file("BepInEx/config/BepInEx.cfg", 4)])]),
        dir("logs", "logs", [file("logs/server.log", 66)]),
      ];
    case "ark":
      return [
        file("start.sh", 1),
        dir("ShooterGame", "ShooterGame", [
          dir("Saved", "ShooterGame/Saved", [
            dir("Config", "ShooterGame/Saved/Config", [dir("LinuxServer", "ShooterGame/Saved/Config/LinuxServer", [file("ShooterGame/Saved/Config/LinuxServer/GameUserSettings.ini", 8), file("ShooterGame/Saved/Config/LinuxServer/Game.ini", 3)])]),
            dir("SavedArks", "ShooterGame/Saved/SavedArks", [bin(`ShooterGame/Saved/SavedArks/${s.worldName}.ark`, 6120330), bin(`ShooterGame/Saved/SavedArks/${s.worldName}_ArkTribeExport.arkprofile`, 1204)]),
          ]),
          dir("Binaries", "ShooterGame/Binaries", [dir("Linux", "ShooterGame/Binaries/Linux", [bin("ShooterGame/Binaries/Linux/ShooterGameServer", 2412040)])]),
        ]),
        dir("logs", "logs", [file("logs/ShooterGame.log", 180)]),
      ];
    case "dragonwilds":
      return [
        file("dragonwilds_server.cfg", 3),
        file("start.sh", 1),
        dir("saves", "saves", [bin(`saves/${w}.realm`, 1420008), bin("saves/global.sav", 340)]),
        dir("logs", "logs", [file("logs/dragonwilds.log", 58)]),
      ];
    case "hytale":
      return [
        file("server.cfg", 4),
        dir("universe", "universe", [dir("worlds", "universe/worlds", [bin(`universe/worlds/${w}/zone1.region`, 920140)])]),
        dir("mods", "mods", installed.length ? installed.map((a) => bin(`mods/${a.name.replace(/\s+/g, "-")}-${a.version}.jar`, 640 + a.name.length * 21)) : [file("mods/README.txt", 1)]),
        dir("logs", "logs", [file("logs/server.log", 47)]),
      ];
    case "terraria":
      return [
        file("serverconfig.txt", 2),
        file("start-server.sh", 1),
        dir("Worlds", "Worlds", [bin(`Worlds/${w}.wld`, 184220), bin(`Worlds/${w}.wld.bak`, 183980)]),
        dir("logs", "logs", [file("logs/server.log", 31)]),
      ];
    case "rust":
      return [
        file("server.cfg", 3),
        file("start.sh", 1),
        dir("oxide", "oxide", [
          dir("config", "oxide/config", [file("oxide/config/Kits.json", 4), file("oxide/config/GatherManager.json", 2)]),
          dir("plugins", "oxide/plugins", installed.length ? installed.map((a) => bin(`oxide/plugins/${a.name.replace(/\s+/g, "")}.cs`, 24 + a.name.length)) : [file("oxide/plugins/README.txt", 1)]),
        ]),
        dir(`server/${s.seed || "procedural"}`, `server/${s.seed || "procedural"}`, [bin(`server/${s.seed || "procedural"}/proceduralmap.4500.${s.seed || "42690"}.240.sav`, 2041220)]),
        dir("logs", "logs", [file("logs/server.log", 92)]),
      ];
    default:
      return [
        file("server.cfg", 2),
        file("start.sh", 1),
        dir("world", "world", [bin("world/save.dat", 420140)]),
        dir("logs", "logs", [file("logs/latest.log", 20)]),
      ];
  }
}

export function templateContent(s: Server, path: string): string | null {
  const g = getGame(s.gameId);
  const mcLike = s.gameId === "minecraft" || s.gameId === "minecraft-modded" || s.gameId === "minecraft-bedrock";
  if (path === "server.properties" && mcLike)
    return [
      `# ${g.name} server properties`,
      `# Managed by Server Hub — manual edits apply on restart`,
      `motd=${s.motd || "A Server Hub server"}`,
      `server-port=${s.port}`,
      `max-players=${s.maxPlayers}`,
      `difficulty=${s.difficulty}`,
      `pvp=${s.pvp}`,
      `level-name=${s.worldName}`,
      s.seed ? `level-seed=${s.seed}` : `level-seed=`,
      `view-distance=10`,
      `simulation-distance=8`,
      `online-mode=true`,
      `spawn-protection=0`,
      `allow-flight=true`,
      `enable-command-block=${s.gameId === "minecraft-modded"}`,
      `white-list=false`,
      ``,
    ].join("\n");
  if (path === "eula.txt") return `# Accepted via Server Hub setup\neula=true\n`;
  if (path === "ops.json") return `[\n  {\n    "uuid": "069a79f4-44e9-4726-a5be-fca90e38aaf5",\n    "name": "HubAdmin",\n    "level": 4,\n    "bypassesPlayerLimit": true\n  }\n]\n`;
  if (path === "banned-players.json") return `[]\n`;
  if (path === "server.properties") return `server-port=${s.port}\nmax-players=${s.maxPlayers}\nmotd=${s.motd}\n`;
  if (path === "start_server.sh" || path === "start_headless_server.sh")
    return `#!/usr/bin/env bash\n# Valheim dedicated launcher (managed)\nexport templdpath=$LD_LIBRARY_PATH\nexport LD_LIBRARY_PATH=./linux64:$LD_LIBRARY_PATH\n./valheim_server.x86_64 -nographics -batchmode \\\n  -name "${s.name}" \\\n  -port ${s.port} \\\n  -world "${s.worldName}" \\\n  -password "********" \\\n  -public 1\nexport LD_LIBRARY_PATH=$templdpath\n`;
  if (path === "BepInEx/config/valheim_plus.cfg")
    return `[Server]\nenabled = true\nenforceMod = false\nmaxPlayers = ${s.maxPlayers}\n\n[Building]\nenabled = true\nnoWeatherDamage = false\nmaximumPlacementDistance = 8\n\n[Map]\nshareMapProgression = true\n`;
  if (path === "BepInEx/config/BepInEx.cfg") return `[Logging.Console]\nEnabled = true\nLogLevels = Fatal, Error, Warning, Message, Info\n`;
  if (path === "ShooterGame/Saved/Config/LinuxServer/GameUserSettings.ini")
    return `[ServerSettings]\nServerName=${s.name}\nSessionName=${s.name}\nServerPassword=\nMaxPlayers=${s.maxPlayers}\nDifficultyOffset=1.0\nTamingSpeedMultiplier=3.0\nHarvestAmountMultiplier=2.0\nXPMultiplier=2.0\nRCONEnabled=True\nRCONPort=${s.port + 1000}\n\n[/Script/ShooterGame.ShooterGameUserSettings]\nMasterAudioVolume=1.0\n`;
  if (path === "ShooterGame/Saved/Config/LinuxServer/Game.ini")
    return `[/script/shootergame.shootergamemode]\nMatingIntervalMultiplier=0.5\nEggHatchSpeedMultiplier=4.0\nBabyMatureSpeedMultiplier=6.0\n`;
  if (path === "dragonwilds_server.cfg")
    return `# RuneScape: Dragonwilds dedicated config\nrealm_name=${s.worldName}\nmax_players=${s.maxPlayers}\nport=${s.port}\npublic=true\nshared_progression=true\ndragon_threat=normal\nautosave_minutes=5\n`;
  if (path === "server.cfg" && s.gameId === "hytale")
    return `# Hytale dedicated server\nuniverse=${s.worldName}\nmax_view_radius=12\nmax_players=${s.maxPlayers}\nbind=0.0.0.0:${s.port}\nmotd=${s.motd}\n`;
  if (path === "server.cfg")
    return `# ${g.name} dedicated config\nhostname=${s.name}\nmaxplayers=${s.maxPlayers}\nport=${s.port}\nworld=${s.worldName}\nseed=${s.seed}\n`;
  if (path === "serverconfig.txt")
    return `world=.local/share/Terraria/Worlds/${s.worldName}.wld\nautocreate=3\nworldname=${s.worldName}\ndifficulty=${["peaceful", "easy", "normal", "hard"].indexOf(s.difficulty)}\nmaxplayers=${s.maxPlayers}\nport=${s.port}\nmotd=${s.motd}\n`;
  if (path === "oxide/config/Kits.json")
    return `{\n  "kits": {\n    "starter": { "cooldown": 3600, "items": ["rock", "torch", "bandage x3"] },\n    "builder": { "cooldown": 86400, "items": ["hammer", "building plan", "wood 5000"] }\n  }\n}\n`;
  if (path === "oxide/config/GatherManager.json") return `{\n  "GlobalScale": 2.0,\n  "Quarries": { "Sulfur": 1.5, "Metal": 2.0 }\n}\n`;
  if (path?.endsWith(".log") || path === "logs/latest.log")
    return `# Live output is streamed in the Console tab.\n# This file rotates; Server Hub tails the active segment.\n`;
  if (path?.endsWith("README.txt"))
    return `Drop ${s.gameId === "rust" ? "Oxide plugin (.cs)" : "mod (.jar/.zip)"} files here.\nInstalled items appear automatically after the next restart.\n`;
  if (path === "world/datapacks/vanilla/pack.mcmeta") return `{\n  "pack": {\n    "pack_format": 61,\n    "description": "The default data for Minecraft"\n  }\n}\n`;
  if (path === "start.sh" || path === "start-server.sh")
    return `#!/usr/bin/env bash\n# Managed launcher — edits apply on next boot\nexec ./runtime --game "${s.gameId}" --port ${s.port} --memory ${s.memoryMb} --world "${s.worldName}"\n`;
  if (path === "permissions.json") return `[\n  { "permission": "operator", "xuid": "2535416949402934" }\n]\n`;
  return "";
}

export function fmtSize(kb: number): string {
  if (kb >= 1024 * 1024) return `${(kb / (1024 * 1024)).toFixed(2)} GB`;
  if (kb >= 1024) return `${(kb / 1024).toFixed(1)} MB`;
  return `${kb} KB`;
}
