import { asc, eq, and, gt } from "drizzle-orm";
import { db } from "@/db";
import { activity, backups, consoleLogs, players, servers, tasks } from "@/db/schema";
import type { Server } from "@/db/schema";
import { getGame, type GameDef } from "./games";
import { clamp, pick, rand, randInt, sleep, steam64, uuidLike } from "./format";

// ---------------------------------------------------------------------------
// Runtime state (per Node process). Server processes are simulated; state is
// reconciled with Postgres so the panel survives reloads.
// ---------------------------------------------------------------------------

export type Metric = { t: number; cpu: number; ram: number; players: number; tps: number | null };

type Phase = "installing" | "starting" | "online" | "stopping";

type Entry = {
  gen: number;
  phase: Phase;
  timers: NodeJS.Timeout[];
  interval?: NodeJS.Timeout;
  metrics: Metric[];
  lastPlayerEvent: number;
};

type SimState = { servers: Map<number, Entry> };

const g = globalThis as typeof globalThis & { __hubSim?: SimState };
if (!g.__hubSim) g.__hubSim = { servers: new Map() };
const state = g.__hubSim;

function entryFor(id: number): Entry | undefined {
  return state.servers.get(id);
}

function sched(e: Entry, ms: number, fn: () => void | Promise<void>) {
  const gen = e.gen;
  const t = setTimeout(() => {
    const live = state.servers.get(e === undefined ? -1 : findId(e) ?? -1);
    if (!live || live.gen !== gen) return;
    void fn();
  }, ms);
  e.timers.push(t);
}

function findId(e: Entry): number | undefined {
  for (const [k, v] of state.servers) if (v === e) return k;
  return undefined;
}

// ---------------------------------------------------------------------------
// DB helpers
// ---------------------------------------------------------------------------

export async function logLine(serverId: number, level: string, source: string, message: string) {
  await db.insert(consoleLogs).values({ serverId, level, source, message });
}

export async function act(serverId: number | null, kind: string, message: string) {
  await db.insert(activity).values({ serverId, kind, message });
}

export async function setStatus(id: number, status: string) {
  await db.update(servers).set({ status, updatedAt: new Date() }).where(eq(servers.id, id));
}

function clock(): string {
  const d = new Date();
  const p = (n: number) => String(n).padStart(2, "0");
  return `${p(d.getHours())}:${p(d.getMinutes())}:${p(d.getSeconds())}`;
}

// ---------------------------------------------------------------------------
// Game-flavored boot / ambient lines
// ---------------------------------------------------------------------------

type BootStep = { level?: string; source?: string; msg: string };

function bootSeq(s: Server, g: GameDef): BootStep[] {
  const t = () => `[${clock()}]`;
  const mx = Math.round(s.memoryMb / 1024);
  switch (s.gameId) {
    case "minecraft":
    case "minecraft-modded": {
      const modded = s.gameId === "minecraft-modded";
      const steps: BootStep[] = [
        { msg: `${t()} [main/INFO]: Booting ${g.dockerImage} with ${mx}G heap` },
        { msg: `${t()} [main/INFO]: Loading server properties` },
        { msg: `${t()} [main/INFO]: Default game type: SURVIVAL` },
      ];
      if (modded)
        steps.push({
          msg: `${t()} [main/INFO]: ${cap(s.loader)} ${s.version} resolving ${randInt(64, 148)} mod jars…`,
        });
      steps.push(
        { msg: `${t()} [main/INFO]: Generating keypair` },
        { msg: `${t()} [main/INFO]: Starting Minecraft server on 0.0.0.0:${s.port}` },
        { msg: `${t()} [main/INFO]: Using epoll channel type` },
        { msg: `${t()} [Server thread/INFO]: Preparing level "${s.worldName}"` },
        { msg: `${t()} [Server thread/INFO]: Preparing start region for dimension minecraft:overworld` },
        { msg: `${t()} [Worker-Main-3/INFO]: Preparing spawn area: ${randInt(34, 58)}%` },
        { msg: `${t()} [Worker-Main-2/INFO]: Preparing spawn area: ${randInt(88, 99)}%` },
        { msg: `${t()} [Server thread/INFO]: Time elapsed: ${randInt(1800, 4200)} ms` },
        {
          level: "success",
          msg: `${t()} [Server thread/INFO]: Done (${rand(3, 8).toFixed(3)}s)! For help, type "help"`,
        }
      );
      return steps;
    }
    case "minecraft-bedrock":
      return [
        { msg: `${t()} INFO] Starting Bedrock server ${s.version}` },
        { msg: `${t()} INFO] Loading level "${s.worldName}"` },
        { msg: `${t()} INFO] IPv4 supported, port: ${s.port}` },
        { msg: `${t()} INFO] IPv6 supported, port: 19133` },
        { level: "success", msg: `${t()} INFO] Server started.` },
      ];
    case "valheim":
      return [
        { msg: `[Valheim] Dedicated server ${s.version}` },
        { msg: `[Valheim] Loaded 10902 reforged prefabs` },
        { msg: `[Valheim] Loading world "${s.worldName}" (seed ${s.seed || "Emberhold"})` },
        { msg: `[Valheim] Zonesystem Start ${randInt(380, 620)}` },
        { msg: `[Valheim] DungeonDB Start` },
        { msg: `[Valheim] Bound to 0.0.0.0:${s.port} (query ${s.port + 1})` },
        { msg: `[Valheim] Got status changed msg k_ESteamNetworkingConnectionState_Connecting` },
        { level: "success", msg: `[Valheim] Game server connected` },
        { msg: `[Valheim] Server join code: ${randInt(100000, 999999)}` },
      ];
    case "ark": {
      const map = s.version.match(/\(([^)]+)\)/)?.[1] ?? "TheIsland";
      return [
        { msg: `Using binned.` },
        { msg: `4.5.1-0+UE4 ${randInt(10000, 40000)}CL ${randInt(300000, 400000)}` },
        { msg: `${ts()}[  0]Commandline: ${map}?SessionName=${encodeURIComponent(s.name)}?Port=${s.port}?QueryPort=${g.queryPort ?? 27015} -server -log` },
        { msg: `${ts()}[  0]Full Startup: ${rand(180, 340).toFixed(2)} seconds (BP compile: ${rand(0.1, 0.9).toFixed(2)}s)` },
        { msg: `${ts()}[  0]Primal Game / INFO: Loaded ${randInt(380, 460)} ARK item entries` },
        { level: "success", msg: `${ts()}[  2]Server: "${s.name}" has successfully started!` },
        { msg: `${ts()}[  7]Log: Steam service online. Assigning server CGameID` },
      ];
    }
    case "dragonwilds":
      return [
        { msg: `${t()} [boot] Dragonwilds dedicated host ${s.version}` },
        { msg: `${t()} [boot] Mounting realm "${s.worldName}" — Ashenfall continent` },
        { msg: `${t()} [boot] Loading rune keystones… ok` },
        { msg: `${t()} [net] Listening on 0.0.0.0:${s.port}/udp` },
        { msg: `${t()} [world] Spawning wildlife populations (drakes, dire wolves)` },
        { level: "success", msg: `${t()} [world] Realm is open. The Dragon Queen stirs in the north.` },
      ];
    case "hytale":
      return [
        { msg: `${t()} [HytaleServer/INFO] Orbis engine ${s.version}` },
        { msg: `${t()} [HytaleServer/INFO] Loading universe "${s.worldName}"` },
        { msg: `${t()} [HytaleServer/INFO] Zone 1 (Emerald Grove) chunks warm` },
        { msg: `${t()} [HytaleServer/INFO] Asset pack registry: ${randInt(120, 180)} packs` },
        { msg: `${t()} [HytaleServer/INFO] Listening on UDP ${s.port}` },
        { level: "success", msg: `${t()} [HytaleServer/INFO] Universe online — welcome to Orbis.` },
      ];
    case "terraria":
      return [
        { msg: `Terraria Server v${s.version}` },
        { msg: `Listening on port ${s.port}` },
        { msg: `Loading world: ${s.worldName}.wld` },
        { msg: `Settling liquids ${randInt(20, 60)}% … ${randInt(80, 99)}%` },
        { level: "success", msg: `Server started` },
      ];
    case "rust":
      return [
        { msg: `[Bootstrap] Rust Dedicated ${s.version} — branch release` },
        { msg: `[Bootstrap] Procedural map seed ${s.seed || String(randInt(1000, 99999))} size 4500` },
        { msg: `[Bootstrap] Loading Oxide/uMod plugins… ${randInt(4, 22)} loaded` },
        { msg: `[Bootstrap] Server listening on 0.0.0.0:${s.port}/udp` },
        { level: "success", msg: `[Bootstrap] Server startup complete — wipe is live.` },
      ];
    default:
      return [
        { msg: `[boot] ${g.name} dedicated server ${s.version}` },
        { msg: `[boot] Loading world "${s.worldName}"` },
        { msg: `[net] Listening on 0.0.0.0:${s.port}/${g.protocol.toLowerCase()}` },
        { level: "success", msg: `[boot] Server online.` },
      ];
  }
}

function ts(): string {
  const d = new Date();
  const p = (n: number) => String(n).padStart(2, "0");
  return `[${d.getFullYear()}.${p(d.getMonth() + 1)}.${p(d.getDate())}-${clock()}:${String(randInt(10, 99))}]`;
}

function cap(s: string) {
  return s.charAt(0).toUpperCase() + s.slice(1);
}

const CHAT = [
  "anyone got spare iron?",
  "base coords in the usual doc",
  "that cave system is HUGE",
  "gg last night",
  "brb, food",
  "who took my diamonds lol",
  "nether portal is finally done",
  "can someone help me move this build?",
  "server has been so smooth lately",
  "raid tonight?",
  "I claim this valley!",
  "watch out, night is falling",
];

const AMBIENT: Record<string, string[]> = {
  minecraft: [
    `[Server thread/INFO]: Saving chunks for level 'ServerLevel[{w}]'/minecraft:overworld`,
    `[Server thread/WARN]: Can't keep up! Is the server overloaded? Running {tpsLag}ms behind`,
    `[Server thread/INFO]: Villager Trader [{p}] rolled new trades`,
    `[Server thread/INFO]: [Dynmap] Loaded 25 surface maps`,
  ],
  "minecraft-modded": [
    `[Server thread/INFO]: Saving chunks for level 'ServerLevel[{w}]'/minecraft:overworld`,
    `[Server thread/INFO]: [create] Schematic cannon finished job #{r}`,
    `[Server thread/INFO]: [jei] Ingredient list synchronized ({r} items)`,
    `[Server thread/WARN]: TPS dipped to {lowTps} — spark profiler captured 10s`,
  ],
  "minecraft-bedrock": [
    `INFO] Player connected: {p}`,
    `INFO] Running AutoCompaction…`,
    `INFO] Saving…`,
  ],
  valheim: [
    `[Valheim] World saved ({r}.00ms)`,
    `[Valheim] Zonesystem SetCustomLocation Complete`,
    `[Valheim] Loading dungeon: crypt{small}`,
    `[Valheim] RPC_ServerSetGlobalKey boss_eikthyr_seeded=false`,
    `[Valheim] Day {r30} — Greydwarfs stir in the Black Forest`,
  ],
  ark: [
    `Primal Game / INFO: Autosaving world state… done in {r2}s`,
    `Log: Dino population check — {r} wild creatures active`,
    `TribeLog: Supply crate spawned at ({r}, {r})`,
    `Log: Night cycle begins. Ambient temp dropping.`,
  ],
  dragonwilds: [
    `[world] Ashen storm rolling in from the north ridge`,
    `[world] Realm autosaved in {r2}s`,
    `[wildlife] A drake has nested near waypoint {small}`,
    `[questline] Party progress synced: The Broken Army (stage {small})`,
  ],
  hytale: [
    `[HytaleServer/INFO] Universe autosaved`,
    `[HytaleServer/INFO] Kweebec village event triggered in Emerald Grove`,
    `[HytaleServer/INFO] Zone 3 portal stabilized ({r}% integrity)`,
  ],
  terraria: [
    `Saving world… done`,
    `A goblin army is approaching from the east!`,
    `Blood moon is rising…`,
    `{p} has smashed a shadow orb`,
  ],
  rust: [
    `[oxide] Plugin check: {small} plugins healthy`,
    `[events] Cargo ship entering harbor`,
    `[events] Patrol helicopter inbound`,
    `[save] Server saved ({r} entities)`,
  ],
  custom: [`[tick] heartbeat ok`, `[save] state flushed`, `[net] {r}ms avg RTT`],
};

function ambientLine(s: Server): { msg: string; level: string } {
  const pool = AMBIENT[s.gameId] ?? AMBIENT.custom;
  let msg = pick(pool);
  const t = () => `[${clock()}]`;
  msg = msg
    .replace("{w}", s.worldName)
    .replace("{p}", pick(getGame(s.gameId).playerPool))
    .replace("{tpsLag}", String(randInt(200, 2400)))
    .replace("{lowTps}", (rand(12, 17)).toFixed(1))
    .replace("{r}", String(randInt(2, 412)))
    .replace("{r2}", String(rand(0.4, 3.2).toFixed(2)))
    .replace("{small}", String(randInt(1, 9)))
    .replace("{r30}", String(randInt(10, 220)));
  const isMcLike = s.gameId.startsWith("minecraft");
  return {
    msg: (isMcLike ? `${t()} ` : "") + msg,
    level: msg.includes("WARN") ? "warn" : "info",
  };
}

// ---------------------------------------------------------------------------
// Metrics
// ---------------------------------------------------------------------------

const BASE: Record<string, { cpu: [number, number]; ramRatio: [number, number] }> = {
  minecraft: { cpu: [7, 24], ramRatio: [0.38, 0.58] },
  "minecraft-modded": { cpu: [16, 44], ramRatio: [0.58, 0.78] },
  "minecraft-bedrock": { cpu: [5, 16], ramRatio: [0.45, 0.6] },
  valheim: { cpu: [5, 17], ramRatio: [0.42, 0.62] },
  ark: { cpu: [24, 58], ramRatio: [0.62, 0.82] },
  dragonwilds: { cpu: [14, 38], ramRatio: [0.5, 0.7] },
  hytale: { cpu: [10, 32], ramRatio: [0.48, 0.68] },
  terraria: { cpu: [3, 12], ramRatio: [0.28, 0.45] },
  rust: { cpu: [28, 62], ramRatio: [0.68, 0.86] },
  custom: { cpu: [4, 14], ramRatio: [0.3, 0.5] },
};

function synthHistory(s: Server, online: boolean): Metric[] {
  const g = getGame(s.gameId);
  const base = BASE[s.gameId] ?? BASE.custom;
  const seedPhase = (s.id * 137) % 100;
  const out: Metric[] = [];
  const now = Date.now();
  let cpu = online ? rand(...base.cpu) : 1.1;
  let ram = online ? s.memoryMb * rand(...base.ramRatio) : 96;
  let pl = online ? randInt(1, Math.max(2, Math.min(6, s.maxPlayers))) : 0;
  for (let i = 89; i >= 0; i--) {
    const t = now - i * 5000;
    const wave = Math.sin((t / 60000 + seedPhase) * 2) * 0.5 + 0.5;
    if (online) {
      cpu = clamp(cpu + rand(-2.4, 2.4) + (wave - 0.5) * 1.6, base.cpu[0] * 0.6, Math.min(96, base.cpu[1] + pl * 1.4));
      ram = clamp(ram + rand(-1.2, 1.5), s.memoryMb * base.ramRatio[0], s.memoryMb * base.ramRatio[1] + pl * 90);
      if (Math.random() < 0.06) pl = clamp(pl + pick([-1, 1]), 0, s.maxPlayers);
    } else {
      cpu = clamp(cpu + rand(-0.3, 0.3), 0.3, 2.4);
      ram = clamp(ram + rand(-4, 4), 64, 140);
      pl = 0;
    }
    const tps = s.gameId.startsWith("minecraft") ? (online ? clamp(20 - (cpu > 60 ? rand(1, 4) : rand(0, 0.6)), 14, 20) : null) : null;
    out.push({ t, cpu: +cpu.toFixed(1), ram: Math.round(ram), players: pl, tps: tps === null ? null : +tps.toFixed(2) });
  }
  return out;
}

export async function metricsFor(s: Server): Promise<Metric[]> {
  const e = entryFor(s.id);
  if (e && e.metrics.length) return e.metrics;
  if (s.status === "online") {
    const attached = await attach(s);
    if (attached?.metrics.length) return attached.metrics;
  }
  return synthHistory(s, s.status === "online" || s.status === "starting");
}

function pushMetric(e: Entry, s: Server, onlineCount: number) {
  const base = BASE[e === undefined ? "custom" : s.gameId] ?? BASE.custom;
  const last = e.metrics[e.metrics.length - 1];
  const cpu = clamp((last?.cpu ?? rand(...base.cpu)) + rand(-3, 3.2), base.cpu[0] * 0.55, Math.min(97, base.cpu[1] + onlineCount * 1.6));
  const ram = clamp((last?.ram ?? s.memoryMb * 0.5) + rand(-1.4, 1.8), s.memoryMb * base.ramRatio[0], s.memoryMb * base.ramRatio[1] + onlineCount * 110);
  const tps = s.gameId.startsWith("minecraft") ? clamp(20 - (cpu > 68 ? rand(0.8, 3.6) : rand(0, 0.4)), 15, 20) : null;
  e.metrics.push({ t: Date.now(), cpu: +cpu.toFixed(1), ram: Math.round(ram), players: onlineCount, tps });
  if (e.metrics.length > 90) e.metrics.shift();
}

// ---------------------------------------------------------------------------
// Player simulation
// ---------------------------------------------------------------------------

async function onlinePlayerNames(serverId: number): Promise<string[]> {
  const rows = await db.select().from(players).where(and(eq(players.serverId, serverId), eq(players.isOnline, true)));
  return rows.map((r) => r.name);
}

async function playerJoin(s: Server, g: GameDef) {
  const existing = await db.select().from(players).where(and(eq(players.serverId, s.id), eq(players.isOnline, false), eq(players.isBanned, false)));
  let name: string;
  if (existing.length && Math.random() < 0.65) {
    const row = pick(existing);
    name = row.name;
    await db.update(players).set({ isOnline: true, ping: randInt(8, 140), lastSeen: new Date() }).where(eq(players.id, row.id));
  } else {
    const taken = new Set(existing.map((r) => r.name));
    const fresh = g.playerPool.filter((p) => !taken.has(p));
    if (!fresh.length) return;
    name = pick(fresh);
    const ext = g.protocol === "UDP" ? steam64() : uuidLike();
    await db.insert(players).values({ serverId: s.id, name, externalId: ext, isOnline: true, ping: randInt(8, 140) });
  }
  const joinMsg = s.gameId === "valheim" ? `[Valheim] Got character ZDOID from ${name}` : s.gameId === "ark" ? `${name} joined this ARK!` : `${name} joined the game`;
  await logLine(s.id, "info", "Server", s.gameId.startsWith("minecraft") ? `[${clock()}] [Server thread/INFO]: ${joinMsg}` : joinMsg);
  await act(s.id, "player", `${name} joined ${s.name}`);
}

async function playerLeave(s: Server) {
  const rows = await db.select().from(players).where(and(eq(players.serverId, s.id), eq(players.isOnline, true)));
  if (!rows.length) return;
  const row = pick(rows);
  const mins = randInt(4, 48);
  await db.update(players).set({ isOnline: false, playMinutes: row.playMinutes + mins, lastSeen: new Date() }).where(eq(players.id, row.id));
  const leaveMsg = s.gameId === "ark" ? `${row.name} left this ARK!` : `${row.name} left the game`;
  await logLine(s.id, "info", "Server", s.gameId.startsWith("minecraft") ? `[${clock()}] [Server thread/INFO]: ${leaveMsg}` : leaveMsg);
  await act(s.id, "player", `${row.name} left ${s.name} · ${mins}m session`);
}

// ---------------------------------------------------------------------------
// Lifecycle
// ---------------------------------------------------------------------------

async function attach(s: Server): Promise<Entry | undefined> {
  let e = entryFor(s.id);
  if (e) return e;
  const g = getGame(s.gameId);
  if (s.status === "online" || s.status === "starting") {
    e = { gen: 1, phase: "online", timers: [], metrics: synthHistory(s, true), lastPlayerEvent: Date.now() };
    state.servers.set(s.id, e);
    startTick(s, e, g);
    if (s.status === "starting") await setStatus(s.id, "online");
    await logLine(s.id, "system", "Daemon", `Attached to running process (pid ${randInt(200, 32000)})`);
    return e;
  }
  if (s.status === "stopping" || s.status === "installing") {
    await setStatus(s.id, "offline");
    await logLine(s.id, "warn", "Daemon", `Panel restarted during ${s.status}; container cleaned up.`);
  }
  return undefined;
}

export async function attachIfNeeded(s: Server) {
  await attach(s);
}

export async function installFlow(id: number) {
  const [s] = await db.select().from(servers).where(eq(servers.id, id));
  if (!s) return;
  const g = getGame(s.gameId);
  const e: Entry = { gen: 1, phase: "installing", timers: [], metrics: [], lastPlayerEvent: Date.now() };
  state.servers.set(id, e);
  const lines: BootStep[] = [
    { level: "system", source: "Daemon", msg: `Provisioning container on node eu-west-1 (${Math.round(s.memoryMb / 1024)}G RAM, image ${g.dockerImage})` },
    { level: "system", source: "Daemon", msg: `Pulling image ${g.dockerImage} …` },
    { level: "system", source: "Daemon", msg: `Downloading ${g.short} server files ${s.version} (${(g.installSizeMb / 1000).toFixed(1)} GB) … ${randInt(18, 42)} MB/s` },
    { level: "system", source: "Daemon", msg: `Writing server config — port ${s.port}/${g.protocol.toLowerCase()}, world "${s.worldName}"` },
  ];
  if (s.gameId === "minecraft-modded")
    lines.push({ level: "system", source: "Daemon", msg: `Resolving ${s.loader} loader for MC ${s.version} from ${g.modSource}…` });
  lines.push(
    { level: "system", source: "Daemon", msg: `Accepting EULA · applying file permissions` },
    { level: "success", source: "Daemon", msg: `Installation complete. Server "${s.name}" is ready to start.` }
  );
  let delay = 350;
  for (const l of lines) {
    const at = delay;
    sched(e, at, async () => {
      await logLine(id, l.level ?? "info", l.source ?? "Daemon", l.msg);
    });
    delay += randInt(500, 1400);
  }
  sched(e, delay + 300, async () => {
    await setStatus(id, "offline");
    await act(id, "server", `Installed ${g.short} ${s.version} on "${s.name}"`);
    state.servers.delete(id);
  });
}

function startTick(s: Server, e: Entry, g: GameDef) {
  e.interval = setInterval(async () => {
    try {
      const names = await onlinePlayerNames(s.id);
      pushMetric(e, s, names.length);
      // ambient line most ticks
      if (Math.random() < 0.72) {
        const a = ambientLine(s);
        await logLine(s.id, a.level, "Server", a.msg);
      }
      // occasional chat from an online player
      if (names.length && Math.random() < 0.18) {
        const who = pick(names);
        const mc = s.gameId.startsWith("minecraft");
        await logLine(s.id, "info", "Chat", mc ? `[${clock()}] [Server thread/INFO]: <${who}> ${pick(CHAT)}` : `<${who}> ${pick(CHAT)}`);
      }
      // join/leave churn
      const since = Date.now() - e.lastPlayerEvent;
      if (since > randInt(22000, 55000) && Math.random() < 0.5) {
        e.lastPlayerEvent = Date.now();
        if (names.length === 0 || Math.random() < 0.6) await playerJoin(s, g);
        else if (names.length > 1) await playerLeave(s);
      }
      // world autosave
      if (Math.random() < 0.06) {
        const saveMsg = g.id === "valheim" ? `[Valheim] World saved (${randInt(80, 420)}.00ms)` : s.gameId === "ark" ? `World Save complete` : `[${clock()}] [Server thread/INFO]: Saved the game`;
        await logLine(s.id, "info", "Server", g.id === "minecraft" || g.id === "minecraft-modded" ? saveMsg : saveMsg);
      }
      void sweepTasks(s.id);
    } catch {
      /* keep the loop alive */
    }
  }, 4200);
}

export async function startFlow(id: number): Promise<{ ok: boolean; reason?: string }> {
  const [s] = await db.select().from(servers).where(eq(servers.id, id));
  if (!s) return { ok: false, reason: "Server not found" };
  if (["online", "starting", "installing"].includes(s.status)) return { ok: false, reason: `Server is ${s.status}` };
  if (entryFor(id)) return { ok: false, reason: "Server already managed" };
  const g = getGame(s.gameId);
  const e: Entry = { gen: 1, phase: "starting", timers: [], metrics: synthHistory(s, false).slice(-30), lastPlayerEvent: Date.now() };
  state.servers.set(id, e);
  await setStatus(id, "starting");
  await db.update(servers).set({ lastStartedAt: new Date() }).where(eq(servers.id, id));
  await logLine(id, "system", "Daemon", `Received start request — booting ${g.short} ${s.version}`);
  await act(id, "power", `Starting ${s.name}`);
  const seq = bootSeq(s, g);
  let delay = 450;
  for (const step of seq) {
    const at = delay;
    sched(e, at, async () => {
      await logLine(id, step.level ?? "info", step.source ?? "Server", step.msg);
    });
    delay += randInt(420, 1050);
  }
  const total = delay;
  sched(e, total, async () => {
    e.phase = "online";
    await setStatus(id, "online");
    await act(id, "power", `${s.name} is online — ${names(s, g)}`);
    startTick(s, e, g);
    // welcome a player or two soon after boot
    sched(e, randInt(4000, 9000), () => playerJoin(s, g));
    if (Math.random() < 0.6) sched(e, randInt(12000, 26000), () => playerJoin(s, g));
  });
  return { ok: true };
}

function names(s: Server, g: GameDef) {
  return `${g.short} listening on :${s.port}`;
}

export async function stopFlow(id: number, reason = "Console"): Promise<{ ok: boolean; reason?: string }> {
  const [s] = await db.select().from(servers).where(eq(servers.id, id));
  if (!s) return { ok: false, reason: "Server not found" };
  const e = entryFor(id);
  if (s.status === "offline") return { ok: false, reason: "Already offline" };
  if (e) {
    e.gen++;
    e.timers.forEach(clearTimeout);
    if (e.interval) clearInterval(e.interval);
    e.phase = "stopping";
  }
  await setStatus(id, "stopping");
  await logLine(id, "system", "Daemon", `Stop requested by ${reason}`);
  const mc = s.gameId.startsWith("minecraft");
  const shutdown = mc
    ? [
        `[${clock()}] [Server thread/INFO]: Stopping the server`,
        `[${clock()}] [Server thread/INFO]: Stopping server`,
        `[${clock()}] [Server thread/INFO]: Saving players`,
        `[${clock()}] [Server thread/INFO]: Saving worlds`,
        `[${clock()}] [Server thread/INFO]: ThreadedAnvilChunkStorage: All dimensions are saved`,
      ]
    : s.gameId === "valheim"
      ? [`[Valheim] Net scene destroyed`, `[Valheim] World saved (final)`, `[Valheim] Server shutdown`]
      : [`[stop] Graceful shutdown requested`, `[save] Flushing world state…`, `[net] Sockets closed`];
  let d = 300;
  for (const line of shutdown) {
    const at = d;
    setTimeout(() => void logLine(id, "info", "Server", line).catch(() => {}), at);
    d += randInt(280, 620);
  }
  setTimeout(
    () =>
      void (async () => {
        await db.update(players).set({ isOnline: false }).where(eq(players.serverId, id));
        await setStatus(id, "offline");
        await logLine(id, "system", "Daemon", `Process exited with code 0`);
        await act(id, "power", `${s.name} stopped`);
        state.servers.delete(id);
      })().catch(() => {}),
    d + 350
  );
  return { ok: true };
}

export async function killFlow(id: number) {
  const [s] = await db.select().from(servers).where(eq(servers.id, id));
  if (!s) return { ok: false };
  const e = entryFor(id);
  if (e) {
    e.gen++;
    e.timers.forEach(clearTimeout);
    if (e.interval) clearInterval(e.interval);
  }
  await db.update(players).set({ isOnline: false }).where(eq(players.serverId, id));
  await setStatus(id, "offline");
  await logLine(id, "error", "Daemon", `Process killed (SIGKILL) — unsaved progress may be lost`);
  await act(id, "power", `${s.name} force-killed`);
  state.servers.delete(id);
  return { ok: true };
}

export async function restartFlow(id: number): Promise<{ ok: boolean; reason?: string }> {
  const [s] = await db.select().from(servers).where(eq(servers.id, id));
  if (!s) return { ok: false, reason: "Server not found" };
  if (s.status === "offline") return startFlow(id);
  await stopFlow(id, "Restart");
  setTimeout(() => void startFlow(id).catch(() => {}), 4200);
  return { ok: true };
}

// ---------------------------------------------------------------------------
// Backups
// ---------------------------------------------------------------------------

export async function createBackup(id: number, label?: string, by = "you") {
  const [s] = await db.select().from(servers).where(eq(servers.id, id));
  if (!s) return null;
  const g = getGame(s.gameId);
  const name = label?.trim() || `backup-${new Date().toISOString().slice(0, 16).replace(/[:T]/g, "-")}`;
  const [row] = await db.insert(backups).values({ serverId: id, name, status: "building", note: `Requested by ${by}` }).returning();
  await logLine(id, "system", "Daemon", `Snapshot started → ${name}.tar.gz`);
  setTimeout(
    () =>
      void (async () => {
        const size = randInt(g.worldSizeMin, g.worldSizeMax);
        await db.update(backups).set({ status: "complete", sizeMb: size }).where(eq(backups.id, row.id));
        await logLine(id, "success", "Daemon", `Snapshot complete — ${name}.tar.gz (${(size / 1000).toFixed(2)} GB, verified)`);
        await act(id, "backup", `Backup "${name}" completed (${(size / 1000).toFixed(1)} GB)`);
      })().catch(() => {}),
    randInt(3500, 7000)
  );
  return row;
}

export async function restoreBackup(serverId: number, backupId: number) {
  const [s] = await db.select().from(servers).where(eq(servers.id, serverId));
  const [b] = await db.select().from(backups).where(eq(backups.id, backupId));
  if (!s || !b) return { ok: false };
  if (s.status !== "offline") return { ok: false, reason: "Stop the server before restoring" };
  await logLine(serverId, "system", "Daemon", `Restoring snapshot ${b.name}.tar.gz …`);
  await logLine(serverId, "system", "Daemon", `Extracting ${(b.sizeMb / 1000).toFixed(2)} GB to /data …`);
  await logLine(serverId, "success", "Daemon", `Restore complete — world state rolled back to ${(b.createdAt ?? new Date()).toISOString()}`);
  await act(serverId, "backup", `Restored backup "${b.name}"`);
  return { ok: true };
}

// ---------------------------------------------------------------------------
// Scheduler (lazy sweep on poll)
// ---------------------------------------------------------------------------

export async function sweepTasks(serverId?: number) {
  const now = new Date();
  const all = await db.select().from(tasks).where(eq(tasks.enabled, true));
  for (const t of all) {
    if (serverId && t.serverId !== serverId) continue;
    if (!t.nextRunAt || t.nextRunAt > now) continue;
    const next = new Date(now.getTime() + t.intervalMin * 60000);
    await db.update(tasks).set({ lastRunAt: now, nextRunAt: next }).where(eq(tasks.id, t.id));
    const [s] = await db.select().from(servers).where(eq(servers.id, t.serverId));
    if (!s) continue;
    if (t.type === "restart") {
      if (s.status === "online") {
        await logLine(s.id, "system", "Scheduler", `Scheduled task "${t.name}": restarting…`);
        void restartFlow(s.id);
        await act(s.id, "task", `Scheduled restart "${t.name}" executed`);
      } else {
        await logLine(s.id, "warn", "Scheduler", `Scheduled task "${t.name}" skipped — server offline`);
      }
    } else if (t.type === "backup") {
      await logLine(s.id, "system", "Scheduler", `Scheduled task "${t.name}": creating backup…`);
      void createBackup(s.id, `auto-${t.name.toLowerCase().replace(/\s+/g, "-")}`, "scheduler");
    } else if (t.type === "broadcast") {
      if (s.status === "online") {
        const mc = s.gameId.startsWith("minecraft");
        await logLine(s.id, "info", "Chat", mc ? `[${clock()}] [Server thread/INFO]: [Scheduler] ${t.payload}` : `[Scheduler] ${t.payload}`);
      }
      await act(s.id, "task", `Scheduled broadcast "${t.name}" executed`);
    } else if (t.type === "command") {
      if (s.status === "online") await runCommand(s, t.payload, "Scheduler");
      await act(s.id, "task", `Scheduled command "${t.name}" executed`);
    }
  }
}

// ---------------------------------------------------------------------------
// Console commands
// ---------------------------------------------------------------------------

export async function runCommand(s: Server, raw: string, issuer = "you") {
  const g = getGame(s.gameId);
  const input = raw.trim().replace(/^\//, "");
  if (!input) return;
  const mc = s.gameId.startsWith("minecraft");
  const stamp = (m: string) => (mc ? `[${clock()}] [Server thread/INFO]: ${m}` : m);
  const print = (m: string, level = "info") => logLine(s.id, level, "Server", stamp(m));
  await logLine(s.id, "command", issuer === "Scheduler" ? "Scheduler" : "Console", stamp(`${issuer === "Scheduler" ? "[scheduler] " : "/"}${input}`));
  const [cmd, ...rest] = input.split(/\s+/);
  const arg = rest.join(" ");
  const online = s.status === "online";

  const needsOnline = () => {
    if (!online) {
      void logLine(s.id, "warn", "Server", stamp(`Cannot execute "${cmd}" — server is not online`));
      return false;
    }
    return true;
  };

  switch (cmd.toLowerCase()) {
    case "help": {
      const cmds = mc
        ? ["help", "say <msg>", "list", "kick <player>", "ban <player>", "pardon <player>", "op <player>", "deop <player>", "save-all", "seed", "tps", "time set <day|night>", "weather <clear|rain>", "whitelist add <player>", "backup [name]", "stop"]
        : ["help", "say <msg>", "list", "kick <player>", "ban <player>", "save", "backup [name]", "stop"];
      await print(`Showing ${cmds.length} commands: ${cmds.join("  ·  ")}`);
      break;
    }
    case "stop": {
      await print("Stopping the server…");
      void stopFlow(s.id, issuer);
      break;
    }
    case "say":
    case "broadcast": {
      if (!needsOnline()) break;
      await logLine(s.id, "info", "Chat", stamp(`[Server] ${arg || "…"}`));
      break;
    }
    case "list": {
      if (!needsOnline()) break;
      const names = await onlinePlayerNames(s.id);
      await print(`There are ${names.length} of a max of ${s.maxPlayers} players online: ${names.join(", ") || "—"}`);
      break;
    }
    case "kick": {
      if (!needsOnline() || !arg) break;
      const rows = await db.select().from(players).where(and(eq(players.serverId, s.id), eq(players.name, arg)));
      if (!rows.length) {
        await print(`Player "${arg}" not found`, "warn");
        break;
      }
      await db.update(players).set({ isOnline: false, lastSeen: new Date() }).where(eq(players.id, rows[0].id));
      await print(`Kicked ${arg} from the game`);
      await act(s.id, "player", `${arg} was kicked by ${issuer}`);
      break;
    }
    case "ban": {
      if (!arg) break;
      const rows = await db.select().from(players).where(and(eq(players.serverId, s.id), eq(players.name, arg)));
      if (!rows.length) {
        await print(`Player "${arg}" not found`, "warn");
        break;
      }
      await db.update(players).set({ isBanned: true, isOnline: false }).where(eq(players.id, rows[0].id));
      await print(`Banned ${arg}: The Ban Hammer has spoken!`);
      await act(s.id, "player", `${arg} was banned by ${issuer}`);
      break;
    }
    case "pardon":
    case "unban": {
      if (!arg) break;
      const rows = await db.select().from(players).where(and(eq(players.serverId, s.id), eq(players.name, arg)));
      if (rows.length) {
        await db.update(players).set({ isBanned: false }).where(eq(players.id, rows[0].id));
        await print(`Unbanned ${arg}`);
        await act(s.id, "player", `${arg} was unbanned by ${issuer}`);
      } else await print(`Player "${arg}" not found`, "warn");
      break;
    }
    case "op":
    case "deop": {
      if (!arg) break;
      const rows = await db.select().from(players).where(and(eq(players.serverId, s.id), eq(players.name, arg)));
      if (rows.length) {
        await db.update(players).set({ isOp: cmd === "op" }).where(eq(players.id, rows[0].id));
        await print(`${cmd === "op" ? "Opped" : "De-opped"} ${arg}`);
        await act(s.id, "player", `${arg} was ${cmd}ped by ${issuer}`);
      } else await print(`Player "${arg}" not found`, "warn");
      break;
    }
    case "save":
    case "save-all": {
      if (!needsOnline()) break;
      await print("Saving the game (this may take a moment!)");
      const e = entryFor(s.id);
      const gen = e?.gen;
      setTimeout(() => {
        const live = entryFor(s.id);
        if (e && live && live.gen !== gen) return;
        void print("Saved the world", "success");
      }, 1200);
      break;
    }
    case "backup": {
      await createBackup(s.id, arg || undefined, issuer);
      break;
    }
    case "seed": {
      if (!mc) {
        await print(`World seed: ${s.seed || "(random)"}`);
        break;
      }
      await print(`Seed: [${s.seed || String(randInt(-(10 ** 9), 10 ** 9))}]`);
      break;
    }
    case "tps": {
      if (!needsOnline()) break;
      const ms = await metricsFor(s);
      const last = ms[ms.length - 1];
      await print(`TPS from last 1m, 5m, 15m: ${last?.tps ?? 20}, 20.0, 20.0`);
      break;
    }
    case "weather": {
      if (!mc || !needsOnline()) break;
      await print(`Set the weather to ${arg || "clear"}`);
      break;
    }
    case "time": {
      if (!mc || !needsOnline()) break;
      await print(`Set the time to ${rest[1] === "night" ? 13000 : 1000}`);
      break;
    }
    case "whitelist": {
      if (!mc) break;
      await print(`Added ${rest[1] ?? arg} to the whitelist`);
      break;
    }
    case "version": {
      await print(`${g.name} dedicated server ${s.version}${s.loader !== "vanilla" ? ` (${s.loader})` : ""}`);
      break;
    }
    default:
      await print(`Unknown or incomplete command "${cmd}". Type "help" for a list.`, "warn");
  }
}

// ---------------------------------------------------------------------------
// Log access
// ---------------------------------------------------------------------------

export async function getLogs(serverId: number, after?: number) {
  if (after && Number.isFinite(after)) {
    return db
      .select()
      .from(consoleLogs)
      .where(and(eq(consoleLogs.serverId, serverId), gt(consoleLogs.id, after)))
      .orderBy(asc(consoleLogs.id))
      .limit(400);
  }
  const rows = await db.select().from(consoleLogs).where(eq(consoleLogs.serverId, serverId)).orderBy(asc(consoleLogs.id)).limit(3000);
  return rows.slice(-400);
}

export async function fleetHealth() {
  const all = await db.select().from(servers);
  let cpu = 0;
  let ram = 0;
  let online = 0;
  let playersOnline = 0;
  for (const s of all) {
    if (s.status !== "online") continue;
    online++;
    const e = entryFor(s.id);
    const m = e?.metrics[e.metrics.length - 1] ?? synthHistory(s, true).at(-1)!;
    cpu += m.cpu;
    ram += m.ram;
    playersOnline += m.players;
  }
  return { cpu: +cpu.toFixed(1), ram: Math.round(ram), online, playersOnline, total: all.length };
}
