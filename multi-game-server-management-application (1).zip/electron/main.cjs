/**
 * Server Hub — desktop shell.
 *
 * Spawns the bundled Next.js standalone server as a child process and shows it
 * in a frameless window. Everything (including the SQLite database) is local —
 * no external services, no accounts, no network access required.
 */
const { app, BrowserWindow, shell, dialog, Menu, Tray, nativeImage } = require("electron");
const path = require("node:path");
const { spawn } = require("node:child_process");
const fs = require("node:fs");

const PORT = Number(process.env.SERVERHUB_PORT || 4321);
const HOST = "127.0.0.1";

let serverProc = null;
let mainWindow = null;
let tray = null;
let shuttingDown = false;

function log(...args) {
  console.log("[serverhub]", ...args);
}

function resolveServerDir() {
  const candidates = [
    path.join(__dirname, "server"), // packaged: resources/server
    path.join(__dirname, "..", "build", "server"), // dev: build/server
  ];
  for (const c of candidates) {
    if (fs.existsSync(path.join(c, "server.js"))) return c;
  }
  return null;
}

function startServer() {
  const dir = resolveServerDir();
  if (!dir) {
    dialog.showErrorBox("Server Hub", "Could not find the bundled server (build/server/server.js).");
    app.quit();
    return;
  }

  const env = {
    ...process.env,
    PORT: String(PORT),
    HOSTNAME: HOST,
    NODE_ENV: "production",
    // Store the database in the user's app data folder so it survives updates.
    SERVERHUB_APPDATA: app.getPath("userData"),
    SERVERHUB_DB: path.join(app.getPath("userData"), "serverhub.db"),
    ELECTRON_RUN_AS_NODE: undefined,
  };
  delete env.ELECTRON_RUN_AS_NODE;

  log("starting server from", dir);
  serverProc = spawn(process.execPath, [path.join(dir, "server.js")], {
    cwd: dir,
    env,
    stdio: ["ignore", "pipe", "pipe"],
  });

  serverProc.stdout.on("data", (d) => process.stdout.write(`[server] ${d}`));
  serverProc.stderr.on("data", (d) => process.stderr.write(`[server] ${d}`));
  serverProc.on("exit", (code) => {
    serverProc = null;
    if (!shuttingDown) {
      dialog.showErrorBox("Server Hub", `The local server stopped unexpectedly (code ${code}).`);
      app.quit();
    }
  });
}

/** Polls /api/health until the server answers, so the window never 404s. */
async function waitForServer(timeoutMs = 60000) {
  const deadline = Date.now() + timeoutMs;
  while (Date.now() < deadline) {
    try {
      const r = await fetch(`http://${HOST}:${PORT}/api/health`);
      if (r.ok) return true;
    } catch {
      /* not up yet */
    }
    await new Promise((r) => setTimeout(r, 350));
  }
  return false;
}

function createWindow() {
  const iconFile = path.join(__dirname, "icon.png");
  mainWindow = new BrowserWindow({
    width: 1480,
    height: 940,
    minWidth: 900,
    minHeight: 640,
    show: false,
    backgroundColor: "#fff8fc",
    title: "Server Hub",
    icon: fs.existsSync(iconFile) ? iconFile : undefined,
    titleBarStyle: process.platform === "darwin" ? "hiddenInset" : "default",
    autoHideMenuBar: true,
    webPreferences: {
      preload: path.join(__dirname, "preload.js"),
      contextIsolation: true,
      nodeIntegration: false,
      sandbox: false,
    },
  });

  mainWindow.once("ready-to-show", () => mainWindow.show());
  mainWindow.on("closed", () => (mainWindow = null));

  // External links open in the user's browser, not inside the app.
  mainWindow.webContents.setWindowOpenHandler(({ url }) => {
    if (url.startsWith("http://127.0.0.1") || url.startsWith(`http://localhost`)) return { action: "allow" };
    shell.openExternal(url);
    return { action: "deny" };
  });

  mainWindow.loadURL(`http://${HOST}:${PORT}/`);
}

function buildMenu() {
  const isMac = process.platform === "darwin";
  Menu.setApplicationMenu(
    Menu.buildFromTemplate([
      ...(isMac ? [{ label: app.name, submenu: [{ role: "quit" }] }] : []),
      { label: "File", submenu: [{ label: "Reload", accelerator: "CmdOrCtrl+R", click: () => mainWindow?.reload() }, { type: "separator" }, { role: "quit" }] },
      { label: "View", submenu: [{ role: "reload" }, { role: "toggleDevTools" }, { type: "separator" }, { role: "resetZoom" }, { role: "zoomIn" }, { role: "zoomOut" }] },
      {
        label: "Server",
        submenu: [
          { label: "Open data folder", click: () => shell.openPath(app.getPath("userData")) },
          { label: `http://${HOST}:${PORT}`, click: () => shell.openExternal(`http://${HOST}:${PORT}`) },
        ],
      },
    ])
  );
}

function createTray() {
  const img = nativeImage.createFromPath(path.join(__dirname, "icon.png"));
  if (img.isEmpty()) return;
  tray = new Tray(img.resize({ width: 16, height: 16 }));
  tray.setToolTip("Server Hub");
  tray.on("click", () => (mainWindow ? mainWindow.show() : createWindow()));
}

const gotLock = app.requestSingleInstanceLock();
if (!gotLock) {
  app.quit();
} else {
  app.on("second-instance", () => {
    if (mainWindow) {
      if (mainWindow.isMinimized()) mainWindow.restore();
      mainWindow.show();
      mainWindow.focus();
    }
  });

  app.whenReady().then(async () => {
    startServer();
    buildMenu();
    createTray();

    const ok = await waitForServer();
    if (!ok) {
      dialog.showErrorBox("Server Hub", "The local server did not start in time. Check the console output for details.");
      app.quit();
      return;
    }
    createWindow();
  });

  app.on("window-all-closed", () => {
    if (process.platform !== "darwin") app.quit();
  });

  app.on("activate", () => {
    if (!mainWindow) createWindow();
  });

  app.on("before-quit", () => {
    shuttingDown = true;
    if (serverProc) {
      try {
        serverProc.kill("SIGTERM");
      } catch {
        /* already gone */
      }
    }
  });
}
