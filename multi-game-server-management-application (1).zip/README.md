# Server Hub 🎀

A game-server command center in the spirit of MCSS — run and monitor servers for
**Minecraft** (vanilla, modded and Bedrock), **Valheim**, **ARK: Survival
Evolved**, **RuneScape: Dragonwilds**, **Hytale**, **Terraria**, **Rust** and any
custom dedicated server.

It ships as a **desktop app** (Windows / macOS / Linux) or as a plain local web
server. Everything runs on your machine: live consoles, players, backups,
schedulers, mod browsers and a file manager — no accounts, no cloud, no
external database.

---

## Run it right now (no build step needed if `build/` exists)

```bash
./run.sh                 # macOS / Linux
run.bat                  # Windows
```

Then open <http://localhost:4321>.

`./run.sh --build` rebuilds the production bundle first. Set `SERVERHUB_PORT` to
change the port. Your data lives in `./data/serverhub.db`.

## Build the desktop app

```bash
./scripts/build-desktop.sh
```

| Platform | Output |
| --- | --- |
| Windows | `dist/ServerHub-Setup-<version>.exe` (NSIS installer) |
| macOS | `dist/ServerHub-<version>-x64.dmg` |
| Linux | `dist/ServerHub-<version>-x64.AppImage` |

Preview the shell without packaging:

```bash
./scripts/build-desktop.sh --dev
```

### What you need

- **Node.js 22.5+** (uses the built-in `node:sqlite`)
- Nothing else. No PostgreSQL, no Redis, no native compilation.

---

## How it works

```
┌──────────────────────┐        ┌──────────────────────────────┐
│  Electron shell      │        │  Next.js standalone server   │
│  (frameless window)  │◄──────►│  bundled at build/server     │
└──────────────────────┘  HTTP  │  spawns as a child process   │
        127.0.0.1:4321         └──────────────┬───────────────┘
                                              │
                                    ┌─────────▼──────────┐
                                    │ SQLite (node:sqlite│
                                    │ no native modules) │
                                    └────────────────────┘
```

- **`src/`** — the Next.js app (App Router, Drizzle ORM, SQLite).
- **`electron/`** — desktop shell; spawns the server, shows a window, tray icon.
- **`build/server/`** — the assembled standalone server (produced by
  `scripts/prepare-standalone.mjs`).
- **`scripts/build-desktop.sh`** — the full build → package pipeline.

### Why SQLite?

The original panel needed a PostgreSQL server running. Embedding SQLite through
Node's built-in `node:sqlite` means the packaged app carries **no native
modules**, so one build runs on every platform with nothing to rebuild. The
database lives in your OS user-data folder
(`~/.serverhub/serverhub.db`, or `%APPDATA%/serverhub` on Windows) and survives
app updates.

Drizzle's `better-sqlite3` entrypoint statically imports the native
`better-sqlite3` package, so `next.config.ts` aliases that import to
`src/db/better-sqlite3-stub.ts`. We always pass our own adapted client, so the
stub is never instantiated.

---

## Features

- **Live console** — streaming terminal with authentic per-game boot logs,
  log-level filters, command history (`↑`/`↓`) and a working command
  interpreter (`help`, `list`, `say`, `kick`, `ban`, `op`, `tps`, `save-all`,
  `backup`, `stop`, …).
- **Server lifecycle** — start / stop / restart / force-kill with a real state
  machine. Servers keep running between requests: ambient logs, autosaves and
  simulated players joining and chatting.
- **Player management** — online/offline/banned views with ping and playtime,
  plus kick / ban / pardon / op / deop.
- **Backups** — snapshots with live build progress, restore (blocked while
  online) and downloadable manifests.
- **Scheduler** — recurring restarts, backups, commands and broadcasts, with a
  lazy cron engine that runs even while you're away.
- **Mod & plugin browser** — game-specific catalogs (Modrinth, Steam Workshop,
  Thunderstore, uMod) with install / enable / uninstall.
- **File manager** — per-game virtual filesystems; config files are editable and
  persisted as overlays, binaries are read-only.
- **Deploy wizard** — pick a game, configure RAM / slots / ports / loaders,
  review and watch the install log stream in.

### Supported games

| Game | Port | Mods | Notes |
| --- | --- | --- | --- |
| Minecraft Java | 25565/TCP | Bukkit plugins | vanilla survival, creative |
| Minecraft Modded | 25565/TCP | Fabric / Forge / NeoForge / Quilt | pack-ready |
| Minecraft Bedrock | 19132/UDP | — | cross-play console + mobile |
| Valheim | 2456/UDP | Thunderstore | viking co-op survival |
| ARK: Survival Evolved | 7777/UDP | Steam Workshop | dinos, tribes, ARKs |
| RuneScape: Dragonwilds | 7777/UDP | Steam Workshop | survival-craft |
| Hytale | 5520/UDP | CurseForge | adventure + minigames |
| Terraria | 7777/TCP | tModLoader / Workshop | 2D sandbox |
| Rust | 28015/UDP | uMod / Oxide | brutal survival |
| Custom / SteamCMD | any | — | bring your own binary |

---

## Configuration

| Variable | Default | Purpose |
| --- | --- | --- |
| `SERVERHUB_PORT` | `4321` | HTTP port |
| `SERVERHUB_DB` | `./data/serverhub.db` | SQLite database path |
| `SERVERHUB_APPDATA` | `./data` | Data folder (desktop: OS user-data) |
| `NODE_ENV` | `production` | Next.js mode |

## Development

```bash
npm install
npm run dev        # http://localhost:3000 (uses ./data/serverhub.db)
npm run build      # production build + standalone server
```

## Packaging notes

- `electron-builder.yml` holds the build config (kept out of `package.json`).
- Icons live in `build-resources/` (`icon.ico`, `icon.icns`, `icon.png`) and were
  generated from a vector source; regenerate them if you rebrand.
- The app is **not code-signed** — macOS Gatekeeper will warn on first launch
  (`right-click → Open`), and Windows SmartScreen will prompt. Add your own
  certificates in `electron-builder.yml` to fix that.
